import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(home: QuoteList()));

class QuoteList extends StatefulWidget {
  const QuoteList({Key? key}) : super(key: key);
  _QuoteListState createState() => _QuoteListState();
}

class _QuoteListState extends State<QuoteList> {

  List<String> Quotes = [
    "With hard work and effort, you can achieve anything",
    "Without hard work, nothing grows but weeds.",
    "Work harder than you think you did yesterday.",
    "Winners embrace hard work. They love the discipline of it, the trade-off they’re making to win. Losers, on the other hand, see it as punishment. And that’s the difference.",
    "Work and you’ll get what you need; work harder and you’ll get what you want."
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        title: Text("Awesome Qutotes"),
        backgroundColor: Colors.redAccent,
        centerTitle: true,
      ),
      body: Column(children: [

      ]),
    );
  }
}
